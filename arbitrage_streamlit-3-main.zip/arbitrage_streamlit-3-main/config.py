
API_KEY = "817c309e5d37829ba411d488fdab5e2a"

SPORTS = [
    "soccer_epl",
    "tennis_atp",
    "basketball_nba",
    "rugbyleague_nrl",
    "horse_racing_uk"
]

BOOKMAKERS = [
    "coral",
    "ladbrokes",
    "betfred",
    "williamhill",
    "paddypower"
]

REGIONS = "uk"
MARKETS = "h2h"
ODDS_FORMAT = "decimal"
